---
name: larkcli-bitable-repo-backfill
description: 用 lark-cli 对飞书多维表格批量回填论文代码库（含字段类型坑位与验证步骤）。
---

# larkcli-bitable-repo-backfill

## 适用场景
- 已有飞书 Wiki/Base 链接
- 需要批量补 `代码库` 字段
- 规则：已有代码库跳过，只处理空值

## 标准流程

### 1) 解析 wiki -> base_token
```bash
lark-cli wiki spaces get_node --params '{"token":"<WIKI_TOKEN>"}'
```
取 `data.node.obj_token` 作为 `base_token`。

### 2) 拉取目标视图记录
```bash
lark-cli base +record-list \
  --base-token <BASE_TOKEN> \
  --table-id <TABLE_ID> \
  --view-id <VIEW_ID> \
  --limit 500
```

### 3) 过滤待处理记录
条件：`代码库` 为空。
保留：`record_id`、`标题`、`原链接`、`地址(PDF附件)`。

### 4) 优先解析表格 PDF 附件（官方信号）
若 `地址` 字段有 PDF 附件，先取 `file_token` 下载：
```bash
lark-cli drive +download --file-token <FILE_TOKEN> --output /tmp/papers/<RECORD_ID>.pdf
```

解析策略：
- 先扫 **第一页底部**（常见 `Code / Project Page / GitHub`）
- 再扫 **Introduction(第1章)** 中的仓库声明（`Code is available at ...`）
- 提取 `github.com/<owner>/<repo>`（含子路径时保留完整 URL）

若附件下载失败（权限/403），再回退到 `原链接` 页面或原链接 PDF 解析。

### 5) 写回单条记录
```bash
lark-cli base +record-upsert \
  --base-token <BASE_TOKEN> \
  --table-id <TABLE_ID> \
  --record-id <RECORD_ID> \
  --json '{"代码库":"[https://github.com/owner/repo](https://github.com/owner/repo)"}'
```

## 关键坑位（高频）

### 坑1：`+record-upsert` JSON 结构
- ✅ 正确：`{"代码库":"..."}`（字段对象本体）
- ❌ 错误：`{"fields":{"代码库":"..."}}`
- 错误会触发：`800010701 Invalid input`

### 坑2：URL字段不能写普通文本占位
- 若写“未找到公开代码库”，飞书会强转成伪链接
- 正确做法：**留空/null**，不要写文本占位

### 坑3：`drive +download` 的 `--output` 必须是当前目录下的**相对路径**
- ❌ 绝对路径会报：`unsafe output path`
- ✅ 先切到工作目录（或在脚本里传 `cwd`），再用例如 `pdfs/<record_id>.pdf`

### 坑4：飞书附件常见 `HTTP 403`（权限/scope）
- 403 不代表附件不存在，通常是当前 token 对该文件无下载权限。
- 回退策略：优先用 `原链接` 下载公开 PDF（CVF/ECVA/OpenReview/ACL 等），继续后续解析。
- 记录失败原因，避免误判为“该论文无 PDF”。

### 坑5：子路径仓库不能丢
- 如 `https://github.com/FangyunWei/SLRT/tree/main/NLA-SLR`
- 不能简化成 `https://github.com/FangyunWei/SLRT`

## 写回后验证
抽样回读 2-3 条：
```bash
lark-cli base +record-get --base-token <BASE_TOKEN> --table-id <TABLE_ID> --record-id <RECORD_ID>
```
确认：
- 已有记录未被覆盖
- 新写入链接可访问
- 空值保持为空（未被伪链接污染）

## 推荐输出模板
- 本轮处理总数
- 已有跳过数
- 新补成功数
- 未找到数（留空）
- 未找到标题清单（供下轮深挖）
