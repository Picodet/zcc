---
name: paper-code-finder
description: 从飞书多维表格论文库批量补全代码仓库，并可进一步抽取 PyTorch/CUDA/复现数据集。
---

# paper-code-finder

从飞书多维表格论文知识库中，为论文批量查找 GitHub 代码仓库，并从 README 提取环境信息（PyTorch 版本、CUDA 版本、复现数据集）写回知识库。

## 触发条件

- 用户要求为知识库中的论文补充代码库链接
- 用户要求查找某篇论文的官方代码仓库
- 用户要求从代码仓库补充环境配置信息
- 用户说“找代码 / 补代码库 / 补充 GitHub 链接 / 查环境 / 补环境信息”
- 用户要求批量阅读 README 提取 PyTorch 版本和复现数据集

## 前置条件

- 飞书多维表格已存在（已知 `base_token` + `table_id`，或可由 wiki token 解析）
- 用户已授权飞书 API 访问
- `lark-cli` 已安装并登录

## 执行流程

### Step 1: 读取知识库记录

```bash
# 若用户提供 wiki 链接，先取 wiki token 解析 node，拿到 obj_token(=base_token)
lark-cli wiki spaces get_node --params '{"token":"<WIKI_TOKEN>"}'

# 读取指定视图记录（推荐带 view-id，避免误改非目标记录）
lark-cli base +record-list --base-token <BASE_TOKEN> --table-id <TABLE_ID> \
  --view-id <VIEW_ID> --limit 500
```

注意：`+record-list` 返回 `fields`、`record_id_list`、`data`（二维数组），要按索引映射字段并对齐 `record_id`。

### Step 2: 识别缺少代码库的记录

筛选「代码库」为空的记录，保留 `record_id + 标题 + 原链接`。

### Step 3: 查找 GitHub 链接（优先级）

1. 表内已有代码库 → 跳过
2. 若 `地址` 字段有 PDF 附件：先执行 Step 3.5 下载并解析 PDF（官方信号优先）
3. 原链接页面（CVF/ECVA/OpenReview/IJCAI 等）直接抽取 `github.com/<owner>/<repo>`
4. 原链接为 PDF 时，从 PDF 文本中抽取 GitHub 链接
5. GitHub 搜索（标题全称 + 简称）并做二次验证（README 是否出现论文标题关键词）
6. 仍找不到 → 留空（不要写伪链接）

### Step 3.5: 下载并解析表格附件 PDF（若存在）

```bash
# 先从 record 的 地址字段取 file_token
# 注意：--output 必须是当前目录下相对路径
cd /tmp/papers
lark-cli drive +download --file-token <FILE_TOKEN> --output ./<RECORD_ID>.pdf
```

解析要点：
- 第一页底部（作者信息下方）经常直接给官方仓库链接
- Introduction 常见“code available at ...”语句
- 提取到子路径仓库时保留完整 URL（例如 `.../tree/main/subdir`）
- 若 `drive +download` 返回 403，立即回退原链接/arXiv 页面，不要阻塞批量流程
- 可额外检查 arXiv comment（常出现 “Code: https://github.com/.../tree/...”）

### Step 4: 批量获取 README / requirements

```bash
for repo in <owner/repo_list>; do
  curl -fsSL "https://raw.githubusercontent.com/${repo}/main/README.md" -o "/tmp/readmes/${repo//\//_}.md" || \
  curl -fsSL "https://raw.githubusercontent.com/${repo}/master/README.md" -o "/tmp/readmes/${repo//\//_}.md"

done
```

同理可尝试 `requirements.txt`、`environment.yml`。

### Step 5: 提取环境信息

#### PyTorch 版本优先级

1. `requirements*.txt` 的 `torch==X.Y.Z`
2. `environment*.yml` 的 `pytorch=X.Y.Z`
3. README 安装命令中的 `torch==X.Y.Z`
4. `torch>=X.Y.Z`（标记为最低版本）

#### 复现数据集优先级

1. README 的 `Datasets / Data Preparation / Getting Started`
2. 配置文件中显式数据集名
3. 只写明确提及的数据集，不推断

### Step 6: 写回知识库（lark-cli）

使用 `+record-upsert` 按 record 更新：

```bash
lark-cli base +record-upsert \
  --base-token <BASE_TOKEN> \
  --table-id <TABLE_ID> \
  --record-id <RECORD_ID> \
  --json '{"代码库":"[https://github.com/owner/repo](https://github.com/owner/repo)"}'
```

关键点：
- `--json` 要传**字段对象本身**，不要再包一层 `{"fields":...}`，否则会报 `800010701 Invalid input`。
- URL 字段写 Markdown 链接可被正确识别。
- “未找到”请保持 `null`/空值；不要写“未找到公开代码库”到 URL 字段（会被飞书强转为坏链接）。

### Step 7: 验证

更新后抽样回读 2-3 条：

```bash
lark-cli base +record-get --base-token <BASE_TOKEN> --table-id <TABLE_ID> --record-id <RECORD_ID>
```

## 已知限制

1. Bitable 附件可能出现 403/权限失败：应先尝试 `lark-cli drive +download --file-token <token>`；失败再回退 `原链接`（arXiv/CVF/ECVA/OpenReview）解析。
2. GitHub README 分支可能是 `master` 而非 `main`，需回退尝试。
3. 子目录仓库（如 `FangyunWei/SLRT/tree/main/NLA-SLR`）应保留子路径，不要简化为根仓库。
4. GitHub 匿名搜索/接口可能受限（429/403）；搜索结果需二次验证后再写回。
5. GitHub API `git/trees` 可能触发匿名 rate limit（403）。批量任务优先使用 `git clone --depth 1` 本地扫描作为回退。
6. 扫描 `tree/<subdir>` 仓库时，优先限制在该子目录内；若递归扫描整个 monorepo，容易混入无关项目的 PyTorch/数据集信息。

## 质量红线

- 不确定的候选仓库不要写入。
- PyTorch/CUDA 必须注明来源（requirements / env / README）。
- `>=` 版本必须标注为最低兼容版本，不得伪装成精确版本。
- 未找到的信息留空，不编造。