---
name: paper-ingest-phase1
version: 1.1.0
description: "论文入库阶段 1：基础信息 + PDF 附件 + 摘要。从论文标题/链接出发，自动检索元数据、下载 PDF、创建多维表格记录并上传附件。"
metadata:
  requires:
    tools: ["web_search", "feishu_bitable_app_table_record", "exec"]
    skills: ["lark-base"]
---

# Paper Ingest Phase 1 — 基础信息 + PDF + 摘要

## 目标
给定论文标题、arXiv ID 或论文链接，完成多维表格记录的创建，包含基础信息、PDF 附件和摘要。

## 适用场景
- 用户说"添加论文""入库""搜一下这篇论文并添加"
- 用户给出论文标题、arXiv 链接、DOI 等

## 目标表格信息

> ⚠️ 以下为默认表格，用户指定其他表格时以用户为准。

| 参数 | 值 |
|------|-----|
| app_token | 询问用户让用户给 |
| table_id | 询问用户让用户给 |

## 完整字段映射

| field_id | field_name | type | 阶段 | 写入规则 |
|----------|-----------|------|------|---------|
| fldNDZrzsW | 标题 | Text(1) | **阶段1** | 论文原始标题 |
| fld4la8lmW | 地址 | Attachment(17) | **阶段1** | PDF 附件，通过 `+record-upload-attachment` 上传 |
| fldU9U4IsD | 领域 | MultiSelect(4) | **阶段1** | 论文所属领域，多选。已有选项：CSLR, SLT, Emotion Recognition, Action Recognition, ISLR, Sign Language Generator, Benchmark, Sign Language Retrieval, CLIP, ASR, Code-switching, Computer Vision, Multimodal Learning, Speech Enhancement, Sign Language, Speaker Role Tagging, LLM, SLR |
| fld4VFedtQ | 来源 | SingleSelect(3) | **阶段1** | 会议/期刊名，**不带年份**。已有选项：CVPR, ICCV, ECCV, TPAMI, IJCV, Arixv, PR, NeurIPS, ICLR, IEEE Trans. Circuits Syst. Video Technol., ICML, EMNLP, WACV, arXiv, Unknown 等。注意：来源字段存在大量带年份的重复选项（如 ICLR 2025、CVPR 2025），应使用不带年份的版本 |
| fldU8uZ0r9 | 发表年 | Text(1) | **阶段1** | 年份（如 "2025"） |
| fld8j492A3 | 原链接 | Url(15) | **阶段1** | `{"link": "URL", "text": "网站名"}`。文本映射：arxiv.org→"arXiv", openaccess.thecvf.com→"CVF", openreview.net→"OpenReview", aclanthology.org→"ACL Anthology", dl.acm.org→"ACM", ecva.net→"ECVA" |
| fldu8eTBpx | 代码库 | Url(15) | **阶段1** | `{"link": "URL", "text": "URL原文"}`。link 和 text 均使用原始 URL，不用 "GitHub" 或 "查看原文" |
| fldmbNPuL9 | 摘要 | Text(1) | **阶段1** | 中文翻译/总结摘要。从 arXiv/会议页面获取英文 abstract 后翻译为中文，保持信息完整 |
| fldW2jVs6O | 评分 | Rating(2) | — | 1-5 星，阶段1不填写 |
| fldwmAVnBS | 架构图 | Attachment(17) | — | 阶段1不填写，留给阶段2 |
| fld0GGomC1 | TL;DR | Text(1) | — | 阶段2填写 |
| fldfcRtoul | 研究问题/任务定义 | Text(1) | — | 阶段2填写 |
| fldvKrOMRD | 方法概述 | Text(1) | — | 阶段2填写 |
| flda3DxrYU | 贡献点 | Text(1) | — | 阶段2填写 |
| fldNMJSoq6 | 创新点候选 | Text(1) | — | 阶段2填写 |
| fldMUpmWPe | 数据集 | MultiSelect(4) | — | 阶段2填写 |
| fld48vq9Fw | 评价指标 | MultiSelect(4) | — | 阶段2填写 |
| fldhkljWmj | 结果一句话 | Text(1) | — | 阶段2填写 |
| fldiRc7sZo | 复现数据集 | MultiSelect(4) | — | 阶段3填写 |
| fld5LynXYW | PyTorch环境 | Text(1) | — | 阶段3填写，从代码库 README 提取 |
| fldH6gk5ZA | CUDA版本 | Text(1) | — | 阶段3填写（可选，可能删除） |
| fldtAvpeE8 | 播客 | Url(15) | — | 暂不填写 |

## 执行步骤

### Step 1：检索论文元数据
1. 用 `web_search` 搜索论文标题
2. 从搜索结果中提取：标题、来源（会议/期刊）、发表年份、arXiv 链接、代码库链接
3. 判断领域（从已有选项中选择）

### Step 2：获取摘要
1. 从搜索结果中提取英文 abstract（arXiv 页面、OpenReview 页面通常会返回）
2. 翻译为中文，保持信息完整
3. 格式：一段连续文本，不需要分点

### Step 3：下载 PDF
```bash
wget -q -O /tmp/<safe-filename>.pdf https://arxiv.org/pdf/<arxiv-id>
```
- 文件名用论文简称或 arxiv ID，避免特殊字符
- 最大 20MB

### Step 4：创建记录
使用 `feishu_bitable_app_table_record` action=create，写入字段：
- 标题（text）
- 来源（single select，不带年份）
- 发表年（text）
- 原链接（url，text=网站名）
- 代码库（url，text=URL原文，如果有的话）
- 领域（multi select）
- 摘要（text，中文翻译）

### Step 5：上传 PDF 附件
```bash
cp /tmp/<file>.pdf ~/<file>.pdf
cd ~ && lark-cli base +record-upload-attachment \
  --base-token 询问用户让用户给 \
  --table-id 询问用户让用户给 \
  --record-id <record_id> \
  --field-id fld4la8lmW \
  --file ./<file>.pdf \
  --name "<file>.pdf"
rm ~/<file>.pdf
```
注意：
- `--field-id` 必须用 field_id（如 fld4la8lmW），不能用字段名
- `--file` 必须用相对路径，不能用绝对路径

### Step 6：回读验证
用 `feishu_bitable_app_table_record` action=get 获取记录，确认所有字段已正确写入。

## 原链接文本映射表

| 域名 | 显示文本 |
|------|---------|
| arxiv.org | arXiv |
| openaccess.thecvf.com | CVF |
| openreview.net | OpenReview |
| aclanthology.org | ACL Anthology |
| dl.acm.org | ACM |
| ecva.net | ECVA |

## 错误处理

| 情况 | 处理 |
|------|------|
| 搜索不到论文 | 告知用户，不创建空记录 |
| 代码库找不到 | 代码库字段留空，不编造 |
| PDF 下载失败 | 记录仍创建，告知用户 PDF 上传失败 |
| 来源选项不存在 | 告知用户，确认后创建新选项 |
| 领域不确定 | 列出候选，请用户确认 |
| arXiv API 限流 | 改用 web_search 搜索摘要 |

## 前置条件
- lark-cli 已登录（用户身份）
- 目标多维表格有写入权限
- 网络可访问 arXiv / web_search

## 写入示例

创建记录时的 fields JSON：
```json
{
  "标题": "Uni-Sign: Toward Unified Sign Language Understanding at Scale",
  "来源": "ICLR",
  "发表年": "2025",
  "原链接": {"link": "https://arxiv.org/abs/2501.15187", "text": "arXiv"},
  "代码库": {"link": "https://github.com/ZechengLi19/Uni-Sign", "text": "https://github.com/ZechengLi19/Uni-Sign"},
  "领域": ["SLT", "CSLR"],
  "摘要": "手语预训练因能提升各类手语理解（SLU）任务的表现而受到越来越多关注。为此，作者提出 Uni-Sign，一个统一的预训练框架……"
}
```
