#!/usr/bin/env python3
"""
从已有 report.json 中读取成功记录，按 figure_bbox 仅裁架构图主体，
并上传到飞书多维表格“架构图”字段，最后通过 bitable API 覆盖旧值（单附件）。

用法:
python scripts/upload_replace_figure_only.py \
  --base-token <BASE_TOKEN> --table-id <TABLE_ID> \
  --report /tmp/figure_caption_test/report.json \
  --out-dir /tmp/figure_caption_test/images_v3_figure_only
"""
import argparse, importlib.util, json, shlex, subprocess
from pathlib import Path
import fitz

FIELD_NAME = "架构图"
DEFAULT_EXTRACTOR = Path(__file__).with_name('batch_extract.py')

def run(cmd, cwd=None):
    p = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return p.returncode, (p.stdout or "") + (p.stderr or "")

def parse_token(upload_output: str):
    try:
        body = upload_output.split('\n', 1)[1] if upload_output.startswith('Uploading attachment:') else upload_output
        j = json.loads(body)
        return j["data"]["attachment"]["file_token"]
    except Exception:
        import re
        m = re.search(r'"file_token"\s*:\s*"([^"]+)"', upload_output)
        return m.group(1) if m else None

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base-token', required=True)
    ap.add_argument('--table-id', required=True)
    ap.add_argument('--report', required=True)
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--extractor', default=str(DEFAULT_EXTRACTOR), help='包含 extract_best 的脚本路径（默认同目录 batch_extract.py）')
    args = ap.parse_args()

    spec = importlib.util.spec_from_file_location('extractor_mod', args.extractor)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    report = json.loads(Path(args.report).read_text(encoding='utf-8'))
    items = [x for x in report['items'] if x.get('status') == 'success']

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    summary = {
        'target': len(items),
        'figure_only_crop_ok': 0,
        'upload_ok': 0,
        'replace_ok': 0,
        'fail': 0,
    }
    logs = []

    for it in items:
        rid = it['record_id']
        pdf = Path(it['pdf_path'])
        try:
            if not pdf.exists():
                raise RuntimeError('pdf_missing')

            res = mod.extract_best(pdf, out_dir)
            if not res:
                raise RuntimeError('no_result')

            # 仅保留 figure 主体，不并 caption
            doc = fitz.open(pdf)
            page = doc[res['page_number'] - 1]
            fb = fitz.Rect(res['figure_bbox'])
            cb = fitz.Rect(res.get('caption_bbox', [])) if res.get('caption_bbox') else fitz.Rect()
            pad = 4
            clip = fitz.Rect(fb.x0 - pad, fb.y0 - pad, fb.x1 + pad, fb.y1 + pad)
            pr = page.rect
            clip = fitz.Rect(max(clip.x0, pr.x0), max(clip.y0, pr.y0), min(clip.x1, pr.x1), min(clip.y1, pr.y1))

            # 强制去掉 caption 区域，避免图下注释/正文混入
            if (not cb.is_empty) and clip.intersects(cb):
                overlap = clip & cb
                if not overlap.is_empty:
                    if cb.y0 >= fb.y0:
                        clip.y1 = min(clip.y1, max(clip.y0 + 1, cb.y0 - 2))
                    else:
                        clip.y0 = max(clip.y0, min(clip.y1 - 1, cb.y1 + 2))
                    clip = fitz.Rect(max(clip.x0, pr.x0), max(clip.y0, pr.y0), min(clip.x1, pr.x1), min(clip.y1, pr.y1))

            if clip.is_empty or clip.get_area() < 800:
                raise RuntimeError('bad_clip')

            img_name = f"{pdf.stem}_keyfig_only.png"
            img_path = out_dir / img_name
            page.get_pixmap(dpi=280, clip=clip, annots=False).save(img_path)
            summary['figure_only_crop_ok'] += 1

            # 上传附件
            cmd_up = (
                f"lark-cli base +record-upload-attachment --base-token {args.base_token} --table-id {args.table_id} "
                f"--record-id {rid} --field-id {shlex.quote(FIELD_NAME)} --file ./{shlex.quote(img_path.name)} --name {shlex.quote(img_path.name)}"
            )
            rc, out = run(cmd_up, cwd=str(out_dir))
            if rc != 0 or '"ok": true' not in out:
                raise RuntimeError('upload_fail: ' + out[:180])
            summary['upload_ok'] += 1

            token = parse_token(out)
            if not token:
                raise RuntimeError('no_file_token')

            # 覆盖字段为单附件（避免多次运行累积）
            payload = json.dumps({'fields': {'架构图': [{'file_token': token, 'name': img_path.name}] }}, ensure_ascii=False)
            cmd_set = (
                'lark-cli api PUT '
                f"/open-apis/bitable/v1/apps/{args.base_token}/tables/{args.table_id}/records/{rid} "
                f"--data {shlex.quote(payload)}"
            )
            rc2, out2 = run(cmd_set)
            if rc2 != 0 or '"code": 0' not in out2:
                raise RuntimeError('replace_fail: ' + out2[:180])
            summary['replace_ok'] += 1
            logs.append({'record_id': rid, 'status': 'ok', 'image': img_path.name, 'file_token': token})

        except Exception as e:
            summary['fail'] += 1
            logs.append({'record_id': rid, 'status': 'fail', 'error': str(e)[:220]})

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    Path(out_dir / 'upload_replace_figure_only_logs.json').write_text(json.dumps(logs, ensure_ascii=False, indent=2), encoding='utf-8')

if __name__ == '__main__':
    main()
