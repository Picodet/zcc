#!/usr/bin/env python3
"""
Batch key-figure extraction from Feishu Bitable records (caption-first).
Usage:
  python scripts/batch_extract.py \
    --base-token <BASE_TOKEN> --table-id <TABLE_ID> --view-id <VIEW_ID> \
    --out-dir /tmp/figure_caption_test
"""
import argparse, json, re, subprocess
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from urllib.request import Request, urlopen
import fitz

CAPTION_RE = re.compile(r'^\s*(Figure|Fig\.?|FIGURE)\s*(\d+)\s*[:.\-]\s*(.+)', re.I)
KEYWORDS = ["overview","architecture","framework","pipeline","method","system","workflow","overall"]
NEG = ["table","ablation","accuracy","wer","bleu","rouge","curve","results","comparison","effects","example","examples","visualization"]


def run(cmd, cwd=None):
    p = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=cwd)
    if p.returncode != 0:
        raise RuntimeError(f"cmd failed: {cmd}\n{p.stderr}\n{p.stdout}")
    return p.stdout


def extract_markdown_url(text):
    if not isinstance(text, str):
        return None
    m = re.search(r'\((https?://[^)]+)\)', text)
    if m:
        return m.group(1)
    m = re.search(r'(https?://\S+)', text)
    return m.group(1) if m else None


def normalize_pdf_url(url):
    if not url:
        return None
    u = url.strip()
    if 'openaccess.thecvf.com' in u and u.endswith('_paper.html'):
        # CVF HTML页常位于 /html/..._paper.html，对应PDF在 /papers/..._paper.pdf
        u2 = u.replace('/html/', '/papers/')
        return u2.replace('_paper.html', '_paper.pdf')
    if 'openreview.net/forum' in u:
        q = parse_qs(urlparse(u).query)
        pid = q.get('id', [None])[0]
        if pid:
            return f'https://openreview.net/pdf?id={pid}'
    if 'aclanthology.org' in u and not u.lower().endswith('.pdf'):
        return u.rstrip('/') + '.pdf'
    if 'proceedings.neurips.cc' in u and 'Abstract-Conference.html' in u:
        return u.replace('-Abstract-Conference.html', '-Paper-Conference.pdf')
    return u


def download_pdf_url(url, out_path: Path):
    req = Request(url, headers={'User-Agent': 'Mozilla/5.0'})
    with urlopen(req, timeout=30) as r:
        data = r.read()
    if len(data) < 1024 or not data.startswith(b'%PDF'):
        raise RuntimeError('downloaded content is not a valid PDF')
    out_path.write_bytes(data)


def block_text(block):
    if block.get("type") != 0:
        return ""
    parts = []
    for line in block.get("lines", []):
        for span in line.get("spans", []):
            parts.append(span.get("text", ""))
    return " ".join(parts).strip()


def score_caption(text):
    t = text.lower(); s = 50 if CAPTION_RE.search(text) else 0
    s += sum(15 for kw in KEYWORDS if kw in t)
    s -= sum(12 for ng in NEG if ng in t)
    return s


def union_rects(rects):
    if not rects: return None
    r = fitz.Rect(rects[0])
    for x in rects[1:]: r |= fitz.Rect(x)
    return r


def is_short_text(block):
    t = block_text(block)
    if not t:
        return False
    words = t.split()
    # 图内标签通常很短；正文行虽然词数不多，但字符更长
    return len(words) <= 8 and len(t) <= 48


def sanitize_block_rect(page_rect, block_rect):
    """过滤异常 bbox（尤其 vector block 可能出现远超页面范围的坐标）。"""
    br = fitz.Rect(block_rect)
    pw, ph = page_rect.width, page_rect.height
    if (
        br.x0 < page_rect.x0 - 0.25 * pw
        or br.y0 < page_rect.y0 - 0.25 * ph
        or br.x1 > page_rect.x1 + 0.25 * pw
        or br.y1 > page_rect.y1 + 0.25 * ph
    ):
        return None
    br = br & page_rect
    if br.is_empty or br.get_area() < 16:
        return None
    return br


def refine_caption_bbox(page, block, figure_number: int):
    """将 caption 锚点收敛到行级，避免 block 误扩成整段正文。"""
    pr = page.rect
    br = sanitize_block_rect(pr, block["bbox"])
    txt = block_text(block)

    if br is not None and br.height <= 0.14 * pr.height and len(txt) <= 240:
        return br

    needles = [f"Figure {figure_number}", f"Fig. {figure_number}", f"Fig {figure_number}"]
    for nd in needles:
        hits = page.search_for(nd)
        if hits:
            r = union_rects(hits)
            if r is not None:
                return r & pr

    return br if br is not None else fitz.Rect(block["bbox"]) & pr


def find_captions(page):
    raw = page.get_text("dict", flags=fitz.TEXT_PRESERVE_IMAGES | fitz.TEXT_COLLECT_VECTORS)
    blocks = raw.get("blocks", [])
    out = []
    for b in blocks:
        if b.get("type") != 0:
            continue
        txt = block_text(b)
        m = CAPTION_RE.search(txt or "")
        if txt and m:
            fig_no = int(m.group(2))
            cap_bbox = refine_caption_bbox(page, b, fig_no)
            out.append({"text": txt, "bbox": cap_bbox, "score": score_caption(txt), "blocks": blocks})
    return out


def propose_figure(page, caption_bbox, blocks):
    pr = page.rect
    page_area = max(pr.get_area(), 1.0)

    def collect_in_band(band):
        graphic_rects = []
        for b in blocks:
            bb = sanitize_block_rect(pr, b["bbox"])
            if bb is None or (not band.intersects(bb)):
                continue
            t = b.get("type")
            # 图形主体仅取 image/vector，避免把 caption/正文并入
            if t in (1, 3):
                if bb.get_area() <= 0.75 * page_area:
                    graphic_rects.append(bb)

        return union_rects(graphic_rects)

    upper = fitz.Rect(pr.x0, pr.y0 + 8, pr.x1, max(pr.y0 + 8, caption_bbox.y0 - 2))
    fig = collect_in_band(upper)
    if fig is None or fig.get_area() < 1200:
        lower = fitz.Rect(pr.x0, min(pr.y1 - 8, caption_bbox.y1 + 2), pr.x1, pr.y1 - 8)
        fig = collect_in_band(lower)

    if fig is not None and fig.get_area() > 0.85 * page_area:
        return None
    return fig


def extract_best(pdf_path: Path, img_dir: Path, crop_mode: str = 'figure_only'):
    doc = fitz.open(pdf_path)
    best = None
    for i, page in enumerate(doc):
        for c in find_captions(page):
            fig = propose_figure(page, c["bbox"], c["blocks"])
            if fig is None:
                continue
            area_ratio = max(0.0, min(1.0, fig.get_area()/max(page.rect.get_area(),1.0)))
            total = c["score"] + area_ratio * 50
            cand = {
                "page_number": i+1,
                "caption_text": c["text"],
                "caption_bbox": list(c["bbox"]),
                "figure_bbox": list(fig),
                "score": round(total,2),
            }
            if best is None or cand["score"] > best["score"]:
                best = cand
    if best is None:
        return None

    page = doc[best["page_number"]-1]
    cap, fig = fitz.Rect(best["caption_bbox"]), fitz.Rect(best["figure_bbox"])

    if crop_mode == 'merged':
        clip = fitz.Rect(fig)
        clip |= cap
        pad = 8
        caption_excluded = False
    else:
        # 默认只保留架构图主体，减少正文/长图注混入
        clip = fitz.Rect(fig)
        pad = 4
        caption_excluded = True

    clip = fitz.Rect(clip.x0-pad, clip.y0-pad, clip.x1+pad, clip.y1+pad)
    clip = fitz.Rect(max(clip.x0,page.rect.x0), max(clip.y0,page.rect.y0), min(clip.x1,page.rect.x1), min(clip.y1,page.rect.y1))

    # figure_only 模式强制剔除 caption 区域，避免误截图注/正文
    if caption_excluded and (not cap.is_empty) and clip.intersects(cap):
        overlap = clip & cap
        if not overlap.is_empty:
            if cap.y0 >= fig.y0:
                clip.y1 = min(clip.y1, max(clip.y0 + 1, cap.y0 - 2))
            else:
                clip.y0 = max(clip.y0, min(clip.y1 - 1, cap.y1 + 2))
            clip = fitz.Rect(max(clip.x0,page.rect.x0), max(clip.y0,page.rect.y0), min(clip.x1,page.rect.x1), min(clip.y1,page.rect.y1))

    img_dir.mkdir(parents=True, exist_ok=True)
    suffix = 'keyfig' if crop_mode == 'merged' else 'keyfig_only'
    out = img_dir / f"{pdf_path.stem}_{suffix}.png"
    page.get_pixmap(dpi=260, clip=clip, annots=False).save(out)

    best.update({
        "merged_bbox": list(clip),
        "confidence": round(min(0.99,max(0.1,best['score']/120)),3),
        "reason": "caption匹配+面积综合得分最高",
        "image_path": str(out),
        "crop_mode": crop_mode,
        "caption_excluded": caption_excluded,
    })
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--base-token', required=True)
    ap.add_argument('--table-id', required=True)
    ap.add_argument('--view-id', required=True)
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--crop-mode', choices=['figure_only', 'merged'], default='figure_only',
                    help='figure_only: 仅架构图主体；merged: 架构图+caption')
    args = ap.parse_args()

    out_dir = Path(args.out_dir); pdf_dir = out_dir/'pdfs'; img_dir = out_dir/'images'
    out_dir.mkdir(parents=True, exist_ok=True); pdf_dir.mkdir(exist_ok=True); img_dir.mkdir(exist_ok=True)

    raw = run(f"lark-cli base +record-list --base-token {args.base_token} --table-id {args.table_id} --view-id {args.view_id} --limit 500")
    data = json.loads(raw)['data']
    fields, rows, rids = data['fields'], data['data'], data['record_id_list']
    i_title, i_addr, i_link = fields.index('标题'), fields.index('地址'), fields.index('原链接')

    report = {"total_records": len(rows), "records_with_pdf_attachment": 0, "tested": 0, "success": 0, "failed": 0, "items": []}
    for rid, row in zip(rids, rows):
        title = row[i_title] if i_title < len(row) else ''
        addr = row[i_addr] if i_addr < len(row) else None
        link = row[i_link] if i_link < len(row) else None

        token, name = None, None
        if isinstance(addr, list):
            for a in addr:
                if isinstance(a, dict) and str(a.get('name','')).lower().endswith('.pdf'):
                    token, name = a.get('file_token'), a.get('name'); break
        if token: report['records_with_pdf_attachment'] += 1

        safe = re.sub(r"[^\w\-]+", "_", title)[:80].strip('_') or rid
        rel_pdf = Path('pdfs') / f"{safe}_{rid}.pdf"
        pdf_path = out_dir / rel_pdf
        item = {"record_id": rid, "title": title, "pdf_name": name, "pdf_path": str(pdf_path)}

        try:
            downloaded = False
            if token:
                try:
                    run(f"lark-cli drive +download --file-token {token} --output '{rel_pdf.as_posix()}'", cwd=str(out_dir))
                    item['download'] = 'ok_lark_cli'; downloaded = True
                except Exception as e:
                    item['download'] = 'fail_lark_cli'; item['download_error'] = str(e)[:220]
            if not downloaded:
                u = normalize_pdf_url(extract_markdown_url(link))
                if not u: raise RuntimeError('no_download_source')
                download_pdf_url(u, pdf_path); item['download'] = 'ok_source_url'; item['source_pdf_url'] = u

            report['tested'] += 1
            res = extract_best(pdf_path, img_dir, crop_mode=args.crop_mode)
            if res: item.update({'status':'success', **res}); report['success'] += 1
            else: item.update({'status':'failed', 'error':'no_caption_candidate'}); report['failed'] += 1
        except Exception as e:
            item.update({'status':'failed','error':str(e)[:400]}); report['failed'] += 1
        report['items'].append(item)

    (out_dir/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['total_records','records_with_pdf_attachment','tested','success','failed']}, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
