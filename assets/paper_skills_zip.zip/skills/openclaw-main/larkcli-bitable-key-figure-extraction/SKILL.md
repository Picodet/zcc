---
name: larkcli-bitable-key-figure-extraction
description: 用 lark-cli 从飞书多维表格批量拉取论文，按 caption-first 规则抽取关键架构图（支持 figure-only/merged），并上传回“架构图”字段。
---

# larkcli-bitable-key-figure-extraction

## 适用场景
- 用户给的是飞书 Wiki/Base 论文表（含 `标题/地址/原链接`）
- 目标是批量验证或抽取“关键架构图”（默认不含 caption 文字区；可选 merged 模式保留 caption）
- 希望产出可审计结果：每篇论文的 bbox、置信度、裁剪图路径、失败原因

## 先决条件
- 已配置可用 `lark-cli`
- 系统 Python 可导入 `fitz`（PyMuPDF）
- 若当前 `python/python3` 指向 Hermes venv 且 `import fitz` 失败，优先改用 `/usr/bin/python3` 运行提取/上传脚本（本环境中 PyMuPDF 安装在系统 Python）
- 表中至少有字段：`标题`、`地址`（附件）、`原链接`

## 标准流程

### 1) Wiki -> Base Token
```bash
lark-cli wiki spaces get_node --params '{"token":"<WIKI_TOKEN>"}'
```
取 `data.node.obj_token` 作为 `<BASE_TOKEN>`。

### 2) 拉取视图记录
```bash
lark-cli base +record-list \
  --base-token <BASE_TOKEN> \
  --table-id <TABLE_ID> \
  --view-id <VIEW_ID> \
  --limit 500
```

### 3) 下载 PDF（两级回退）
1. **优先** `地址` 附件的 `file_token`：
```bash
lark-cli drive +download --file-token <FILE_TOKEN> --output 'pdfs/<name>.pdf'
```
2. 若附件下载失败（常见 403），回退 `原链接`：
   - arXiv: `/abs/<id>` 需改为 `/pdf/<id>.pdf`
   - CVF: `/html/..._paper.html` 需改为 `/papers/..._paper.pdf`
   - OpenReview: `forum?id=xxx -> pdf?id=xxx`
   - ACL Anthology: 补 `.pdf`
   - NeurIPS: `.../hash/<id>-Abstract-Conference.html` 常需改为 `.../file/<id>-Paper-Conference.pdf`
   - IJCAI: `.../proceedings/<year>/<num>` 需补零为 `/<num:04d>.pdf`

### 4) caption-first 抽图
- **执行口径：人工初筛，然后代码截图。**
- 先人工确定目标 Figure 编号与是否属于方法架构图；仅把代码用于定位 bbox、裁切和上传。
- 若未完成人工初筛，不得直接按自动评分结果上传。
- caption regex：`^\s*(Figure|Fig\.?)\s*\d+\s*[:.\-]`
- **不要只靠关键词（如 framework/architecture）自动判图**；同一论文的 Figure 1 / Figure 2 可能都含这些词，容易误选。
- **硬性禁用数据图/统计图作为架构图**：折线图、柱状图、散点图、相关性图、分布图、性能对比图、消融曲线/热图一律排除，即便 caption 出现 method/framework 词也不能上传。
- 发现 caption 含 `effects/examples/visualization` 等词时，默认降权；这类图大概率是分析/示例图而非主框架图。
- 对数据集/基准类论文，若不存在模型总览图，优先选择“任务定义/标注流程/评测协议”图，而不是示例图。
- 必须先读取候选 caption 全文，再结合图像内容做语义判断：这张图是否真的是“方法总览/系统框架”，而不是结果图、案例图、数据集示意图、模块局部图。
- 在 caption 邻域找 figure 主体（image block + vector block）后，必须做二次核验：图中的模块、箭头、输入输出是否与 caption 语义一致。
- 计算 `merged_bbox = union(figure_bbox, caption_bbox) + padding` 仅用于候选定位；正式上传前优先裁 `figure_bbox` 主体，不要因为 caption 长文本把正文一并裁入。
- `figure_only` 模式下强制执行 **caption exclusion**：若最终 clip 与 caption 区域相交，自动裁掉相交部分。
- caption 锚点需先做行级收敛（必要时用 `Figure N/Fig. N` 文本定位），避免 caption block 异常膨胀导致“整段正文被当作图注”。
- `page.get_pixmap(clip=..., dpi>=260)` 导出 PNG。

### 5) 上传到 `架构图` 附件字段（不是只存本地）
- **不要**用 `record-upsert` 写 attachment 字段（常见 `READONLY` 忽略）
- 用专用命令：
```bash
lark-cli base +record-upload-attachment \
  --base-token <BASE_TOKEN> \
  --table-id <TABLE_ID> \
  --record-id <RECORD_ID> \
  --field-id 架构图 \
  --file ./images/<FILE>.png \
  --name <FILE>.png
```
- 成功后再 `+record-get` 抽样验证 `架构图` 字段已出现 file_token。

### 6) 输出结构化结果
每条至少输出：
- `record_id`
- `title`
- `page_number`
- `caption_text`
- `caption_bbox`
- `figure_bbox`
- `merged_bbox`
- `confidence`
- `reason`
- `image_path`
- `status` / `error`

并输出汇总：
- `total_records`
- `records_with_pdf_attachment`
- `tested`
- `success`
- `failed`
- `error_breakdown`

## 关键坑位

### 坑1：`drive +download --output` 路径限制
- 必须是当前工作目录下的**相对路径**。
- 绝对路径会报：`unsafe output path`。

### 坑2：附件 403 不等于“无 PDF”
- 常见是权限/scope 问题。
- 必须回退 `原链接` 下载，避免误判。

### 坑3：下载到的内容可能不是 PDF
- 需验证文件头 `%PDF`。
- 否则标记 `not valid PDF`。

### 坑4：站点链接规则差异导致假 404
- CVF 若只把 `_paper.html` 改后缀、不改 `/html/` 到 `/papers/`，会 404。
- NeurIPS 许多页面的 PDF 实际在 `/file/` 路径，不在 `/hash/` 路径。
- IJCAI 论文号常需四位补零（如 `584 -> 0584.pdf`）。
- 失败原因要写入报告，便于二次补救。

### 坑5：只抽 image 会漏掉矢量架构图
- 必须使用页面局部裁切（clip），不要只导出嵌入图片对象。

### 坑6：矢量块 bbox 异常会导致“整页截图”
- 部分 PDF 的 vector block 可能给出远超页面边界的 bbox（例如负数上万）。
- 处理方式：
  - 先做 bbox 合法性过滤（超出页面 25% 以上直接丢弃）
  - 再与 page rect 求交
  - 丢弃面积接近整页的图形噪声块（如 >75% page area）
- 在本环境默认不再吸收文本块进 `figure_bbox`，并通过 caption exclusion 阻断图注/正文混入。

### 坑7：若要“覆盖旧架构图”，不要只追加上传
- `record-upload-attachment` 默认是追加/写入附件。
- 覆盖旧值可用 `lark-cli api PUT /open-apis/bitable/v1/apps/{base}/tables/{table}/records/{record}`
  并在 `fields.架构图` 里仅保留最新 `file_token`。

### 坑8：`record-list` 在当前 CLI 形态常返回矩阵，不是 `items[]`
- 常见结构是：`data.fields` + `data.data` + `data.record_id_list`。
- 解析时要先用 `fields.index("架构图")/fields.index("标题")` 建立列索引，再按行读取。
- 不能假设 `data.items[i].fields` 一定存在，否则会把“缺失架构图”统计错。

### 坑9：`record-get` 回包在当前环境常是“字段扁平化”
- 常见可用路径：`data.record["架构图"]`（而不是固定 `data.record.fields.架构图`）。
- 做上传后核验时，建议同时兼容两种路径，避免把成功写回误判为失败。

### 坑10：CVF/附件下载偶发 SSL EOF 或 403 时，标题级 arXiv 回退更稳
- 现象：`drive +download` 403，或直接请求 CVF PDF 出现 `SSL: UNEXPECTED_EOF_WHILE_READING`。
- 可用回退：按标题查询 arXiv（例如 export API），命中后改用 `https://arxiv.org/pdf/<id>.pdf` 下载再抽图。
- 该回退尤其适合已知论文通常有 arXiv 版本的视觉会议论文。

## 最小验收
- 不仅检查是否抽到图，还要先核对“是否抽对图”：caption 是否对应 overview/architecture/framework/system/pipeline，而不是结果图、案例图、数据集示意图。
- 每次批量或单篇处理后，必须逐条执行核验；不能只抽样看 3-5 张就结束。
- 核验至少包含三项：
  1. **图是否找对**：caption 与论文方法主线一致，且图内容与标题/方法概述能互相对应。
  2. **裁切是否合格**：默认仅保留架构图主体并去掉 caption 文本区；仅在用户明确要求时使用 merged 保留 caption；任何模式都不能混入大段正文、标题、作者区。
  3. **回写是否成功**：飞书 `架构图` 字段回读后应出现最新 file_token。
- 报告中成功项必须包含 bbox + confidence + image_path。
- 失败项必须有明确 error（403/404/418/not_pdf/no_caption/selected_wrong_figure/crop_too_large）。
- 若仅发现数据图/统计图候选，必须返回 `no_valid_architecture_figure_need_manual_review`，并保持飞书“架构图”字段不写入。

## 发现提取有问题时的修复顺序
1. **先判断错因**：是找错 figure、bbox 过大、caption 过长导致并入正文，还是 PDF 下载源不对。
2. **若找对 caption 但裁错**：优先缩小到 `figure_bbox` 主体，不直接用整块 merged 区域。
3. **若 vector bbox 吞正文**：对接近整页或贴近页顶/页底的大框降权，必要时人工限定在 caption 上方最近的连通图形簇。
4. **若 caption 对但仍难判断**：结合表内“研究问题/方法概述/贡献点”，必要时回读论文方法段落后再决定是否重裁；仍不稳时可人工指定目标 Figure 编号（如强制 Figure 2/3）重抽。
5. **修复后必须重新上传并再次核验**，不能假定修复成功；若需要覆盖旧图，务必用 API PUT 将 `架构图` 置为最新单附件。

## 内置脚本（已打包）
- `scripts/batch_extract.py`
  - 批量下载 + caption-first 定位 + 裁切 + 产出 `report.json`
  - 支持 `--crop-mode figure_only|merged`（默认 `figure_only`）
- `scripts/upload_replace_figure_only.py`
  - 读取 `report.json` 成功项，重新按 `figure_bbox` 裁主体图
  - 上传到“架构图”字段，并用 Bitable API 覆盖为单附件（避免重复累积）

## 快速用法
```bash
# 1) 先跑批量提取
python scripts/batch_extract.py \
  --base-token <BASE_TOKEN> \
  --table-id <TABLE_ID> \
  --view-id <VIEW_ID> \
  --out-dir /tmp/figure_caption_test \
  --crop-mode figure_only

# 2) 再上传并覆盖“架构图”字段
python scripts/upload_replace_figure_only.py \
  --base-token <BASE_TOKEN> \
  --table-id <TABLE_ID> \
  --report /tmp/figure_caption_test/report.json \
  --out-dir /tmp/figure_caption_test/images_v3_figure_only
```

## 缓存与归档规范（强制）
- 批处理输出目录必须按日期归档：`<out-dir>/YYYY-MM-DD/`。
- 截图文件名必须带日期+时间戳，避免不同论文/不同轮次重名覆盖。
- 每轮输出 `report.json` 外，再保留带时间戳的运行元数据（建议 `run_YYYYMMDD_HHMMSS.json`）。
- 用户要求“清缓存重跑”时，必须先删除旧缓存目录，再下载 PDF、重新裁切、重新上传。

## 与 `larkcli-bitable-architecture-figure-verified` 的关系（融合说明）
- 本 skill 负责 **批量抽图与回写架构图**（阶段 A）。
- `larkcli-bitable-architecture-figure-verified` 负责 **逐条人工真核验 + 架构图解读联动**（阶段 B）。
- 两者不再各自维护不同裁切口径：当前统一为“默认剔除 caption 文本区，除非用户显式要求 merged”。
- 若任务要求“架构图 + 架构图解读”一起交付，优先走 verified skill；其脚本策略与本 skill 已对齐。

## 推荐交付格式
1) 一段结论（成功率 + 主要失败原因）
2) 成功 Top N 示例（title/page/confidence）
3) 失败清单（title + error + 下一步修复建议）
4) 若用户要求联动解释列，转用 `larkcli-bitable-architecture-figure-verified`，同步产出“架构图”与“架构图解读”。

