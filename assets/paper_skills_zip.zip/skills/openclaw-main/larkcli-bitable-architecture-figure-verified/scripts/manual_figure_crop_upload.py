#!/usr/bin/env python3
"""
人工确认后使用：按“已确认的 Figure 编号 + 页码”从 PDF 裁切架构图，并回写飞书附件字段（覆盖旧值为单附件）。

关键约束：
- 本脚本不做候选图初筛、不做自动选优。
- 必须先人工确认目标 Figure（编号与页码）。
- 若未找到该 Figure caption，直接失败退出，不上传。

用法示例：
  /usr/bin/python3 scripts/manual_figure_crop_upload.py \
    --base-token 询问用户让用户给 \
    --table-id 询问用户让用户给 \
    --record-id recxxxxxxxx \
    --pdf /tmp/paper.pdf \
    --figure-number 3 \
    --page-hint 4 \
    --out-dir /tmp/arch_manual
"""

import argparse
import json
import re
import shlex
import subprocess
from datetime import date, datetime
from pathlib import Path

import fitz

CAPTION_RE = re.compile(r"^\s*(Figure|Fig\.?)\s*(\d+)\s*[:.\-]\s*(.+)", re.I)


def run(cmd: str, cwd: str | None = None):
    p = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True)
    return p.returncode, p.stdout, p.stderr


def block_text(block: dict) -> str:
    if block.get("type") != 0:
        return ""
    parts = []
    for line in block.get("lines", []):
        for span in line.get("spans", []):
            parts.append(span.get("text", ""))
    return " ".join(parts).strip()


def union_rects(rects):
    if not rects:
        return None
    r = fitz.Rect(rects[0])
    for x in rects[1:]:
        r |= fitz.Rect(x)
    return r


def is_short_text(block: dict) -> bool:
    t = block_text(block)
    if not t:
        return False
    words = t.split()
    return len(words) <= 8 and len(t) <= 48


def sanitize_block_rect(page_rect: fitz.Rect, block_rect):
    br = fitz.Rect(block_rect)
    pw, ph = page_rect.width, page_rect.height
    if (
        br.x0 < page_rect.x0 - 0.25 * pw
        or br.y0 < page_rect.y0 - 0.25 * ph
        or br.x1 > page_rect.x1 + 0.25 * pw
        or br.y1 > page_rect.y1 + 0.25 * ph
    ):
        return None
    br = br & page_rect
    if br.is_empty or br.get_area() < 16:
        return None
    return br


def localize_figure_bbox(page: fitz.Page, caption_bbox: fitz.Rect, blocks: list[dict]):
    """仅在已确认的 caption 周边定位图框；不做候选排序。

    注意：这里严格只取图形块，不再拼接任何文本块，避免把 caption/正文误裁进去。
    """
    pr = page.rect
    page_area = max(pr.get_area(), 1.0)

    def collect_in_band(band):
        graphic_rects = []
        for b in blocks:
            bb = sanitize_block_rect(pr, b["bbox"])
            if bb is None or (not band.intersects(bb)):
                continue
            t = b.get("type")
            if t in (1, 3):
                if bb.get_area() <= 0.75 * page_area:
                    graphic_rects.append(bb)

        return union_rects(graphic_rects)

    upper = fitz.Rect(pr.x0, pr.y0 + 8, pr.x1, max(pr.y0 + 8, caption_bbox.y0 - 2))
    fig = collect_in_band(upper)
    if fig is None or fig.get_area() < 1200:
        lower = fitz.Rect(pr.x0, min(pr.y1 - 8, caption_bbox.y1 + 2), pr.x1, pr.y1 - 8)
        fig = collect_in_band(lower)

    if fig is not None and fig.get_area() > 0.85 * page_area:
        return None
    return fig


def refine_caption_bbox(page: fitz.Page, block: dict, figure_number: int) -> fitz.Rect:
    """把 caption 锚点收敛到行级，避免 block 误扩成大段正文。"""
    pr = page.rect
    br = sanitize_block_rect(pr, block["bbox"])
    txt = block_text(block)

    # 常规情况下，直接用合理大小的 block 即可
    if br is not None and br.height <= 0.14 * pr.height and len(txt) <= 240:
        return br

    # block 异常偏大时，回退到 search_for 的短锚文本
    needles = [f"Figure {figure_number}", f"Fig. {figure_number}", f"Fig {figure_number}"]
    for nd in needles:
        hits = page.search_for(nd)
        if hits:
            r = union_rects(hits)
            if r is not None:
                return r & pr

    # 最后兜底
    return br if br is not None else fitz.Rect(block["bbox"]) & pr


def find_confirmed_caption(pdf_path: Path, figure_number: int, page_hint: int):
    doc = fitz.open(pdf_path)
    if page_hint < 1 or page_hint > len(doc):
        return None

    page = doc[page_hint - 1]
    raw = page.get_text("dict", flags=fitz.TEXT_PRESERVE_IMAGES | fitz.TEXT_COLLECT_VECTORS)
    blocks = raw.get("blocks", [])

    for b in blocks:
        if b.get("type") != 0:
            continue
        txt = block_text(b)
        m = CAPTION_RE.match(txt)
        if not m:
            continue
        if int(m.group(2)) != figure_number:
            continue

        caption_bbox = refine_caption_bbox(page, b, figure_number)
        fig = localize_figure_bbox(page, caption_bbox, blocks)
        if fig is None:
            return None

        return {
            "page_number": page_hint,
            "caption_text": txt,
            "caption_bbox": list(caption_bbox),
            "figure_bbox": list(fig),
        }

    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-token", required=True)
    ap.add_argument("--table-id", required=True)
    ap.add_argument("--record-id", required=True)
    ap.add_argument("--pdf", required=True, help="本地 PDF 路径")
    ap.add_argument("--figure-number", required=True, type=int, help="人工确认后的 Figure 编号")
    ap.add_argument("--page-hint", required=True, type=int, help="人工确认页码（1-indexed，必填）")
    ap.add_argument("--out-dir", required=True, help="缓存归档根目录（脚本会自动追加 YYYY-MM-DD 子目录）")
    ap.add_argument("--date-tag", default=date.today().isoformat(), help="日期标签，默认当天 YYYY-MM-DD")
    ap.add_argument("--field-name", default="架构图")
    ap.add_argument("--dpi", type=int, default=300)
    args = ap.parse_args()

    pdf_path = Path(args.pdf)
    if not pdf_path.exists():
        raise SystemExit(f"pdf not found: {pdf_path}")

    out_dir = Path(args.out_dir) / args.date_tag
    out_dir.mkdir(parents=True, exist_ok=True)

    found = find_confirmed_caption(pdf_path, args.figure_number, args.page_hint)
    if not found:
        raise SystemExit("confirmed figure caption not found (or bbox invalid); stop without upload")

    doc = fitz.open(pdf_path)
    page = doc[found["page_number"] - 1]
    fig = fitz.Rect(found["figure_bbox"])
    cap = fitz.Rect(found["caption_bbox"])
    clip = fitz.Rect(fig.x0 - 4, fig.y0 - 4, fig.x1 + 4, fig.y1 + 4) & page.rect

    # 强制去掉 caption 文本区域，避免把图下注释或正文一并截入
    if (not cap.is_empty) and clip.intersects(cap):
        overlap = clip & cap
        if not overlap.is_empty:
            # caption 在下方（最常见）
            if cap.y0 >= fig.y0:
                clip.y1 = min(clip.y1, max(clip.y0 + 1, cap.y0 - 2))
            # 少数 caption 在上方
            else:
                clip.y0 = max(clip.y0, min(clip.y1 - 1, cap.y1 + 2))
            clip = clip & page.rect

    if clip.is_empty or clip.get_area() < 800:
        raise SystemExit("invalid clip area after caption exclusion; stop without upload")

    stem = re.sub(r"[^\w\-]+", "_", pdf_path.stem)[:80].strip("_") or "paper"
    run_ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    image_name = f"{stem}_fig{args.figure_number}_{args.date_tag}_{run_ts}_manual_verified.png"
    image_path = out_dir / image_name
    page.get_pixmap(dpi=args.dpi, clip=clip, annots=False).save(image_path)

    cmd_up = (
        f"lark-cli base +record-upload-attachment --base-token {args.base_token} --table-id {args.table_id} "
        f"--record-id {args.record_id} --field-id {shlex.quote(args.field_name)} "
        f"--file ./{shlex.quote(image_name)} --name {shlex.quote(image_name)}"
    )
    rc, out, err = run(cmd_up, cwd=str(out_dir))
    if rc != 0:
        raise SystemExit(f"upload failed\n{out}\n{err}")

    body = out.split("\n", 1)[1] if out.startswith("Uploading attachment:") else out
    j = json.loads(body)
    token = j["data"]["attachment"]["file_token"]

    payload = json.dumps({"fields": {args.field_name: [{"file_token": token, "name": image_name}]}}, ensure_ascii=False)
    cmd_set = (
        f"lark-cli api PUT /open-apis/bitable/v1/apps/{args.base_token}/tables/{args.table_id}/records/{args.record_id} "
        f"--data {shlex.quote(payload)}"
    )
    rc2, out2, err2 = run(cmd_set)
    if rc2 != 0 or '"code": 0' not in out2:
        raise SystemExit(f"replace failed\n{out2}\n{err2}")

    result = {
        "ok": True,
        "record_id": args.record_id,
        "page_number": found["page_number"],
        "figure_number": args.figure_number,
        "caption_text": found["caption_text"],
        "caption_excluded": True,
        "image_path": str(image_path),
        "file_token": token,
        "date_tag": args.date_tag,
        "run_ts": run_ts,
    }

    meta_path = out_dir / f"{stem}_fig{args.figure_number}_{args.date_tag}_{run_ts}_meta.json"
    meta_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
