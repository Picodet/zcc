论文技能包（面向飞书多维表格 询问用户让用户给）

包含范围：
1) 论文入库与PDF回填下载
2) 代码库检索与回填
3) 摘要/原理一句话/三字段清洗
4) 标签精简回填
5) 关键架构图抽取、人工核验与图解联动
6) Related Work 片段严格内文解析
7) 单篇论文结构化总结

目标多维表格：
- base: 询问用户让用户给
- table: 询问用户让用户给

目录结构：
- skills/openclaw-main/<skill-name>/SKILL.md
- 若技能自带 scripts/references/templates，会一并包含

